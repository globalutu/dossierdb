<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Providers\InterfaceServiceProvider;
use DB;
use App\Models\Trace;
use App\Models\Dossier;
use App\Models\Rencontre;
use App\Models\Tresorerie;

class GestionnaireController extends Controller
{

    ////////////////////////////////////Dossiers/////////////////////////////////////////////
    //
    public function dash()
    {
        $list = DB::table('dossiers');
        
        if(request('rec') == 1){
            if(request('check') != "" && request('check') != null){
                $search = request('check');
                $list = $list->where('denomination', 'like', '%'.$search.'%')
                ->orwhere('nom', 'like', '%'.$search.'%')
                ->orwhere('prenom', 'like', '%'.$search.'%');
            }
        }
        $list = $list->orderby("id", "desc")->paginate(50);
        return view('viewadmindste.dash', compact("list"));
    }

    public function setdos(Request $request){

    	if (isset(DB::table('dossiers')->where('denomination', $request->denom)->where('prenom', $request->prenom)->where('nom', $request->nom)->where('montant', $request->montant)->where('datedebut', $request->datedebut)->first()->id)) {
    		// Erreur 
    		flash("Le dossiers ".$request->denom." existe déjà ")->error();
    	} else {
    		$request->validate([
                    'denom' => 'required|string',
                    'prenom' => 'required|string', 
                    'nom' => 'required|string', 
                    'objet' => 'required|string', 
                    'montant' => 'required|integer', 
                    'datedebut' => 'required|date', 
                    'datefin' => 'required|date', 
                ]);


    		$add = new Dossier();
	    	$add->denomination = $request->denom;
	    	$add->prenom = $request->prenom;
	    	$add->nom = $request->nom;
	    	$add->objet = $request->objet;
	    	$add->montant = $request->montant;
	    	$add->datedebut = $request->datedebut;
	    	$add->datefin = $request->datefin;
	    	$add->save();
	    	flash('Enregistrement effectué avec succès.');
    	}
    	return Back();

    }

    public function deldos(Request $request)
    {
        if (!in_array("delete_vc", session("auto_action"))) {
            return view("vendor.error.649");
        }else{
            $occurence = json_encode(Dossier::where('id', request('id'))->first());
            $addt = new Trace();
            $addt->libelle = "Dossier supprimé : ".$occurence;
            $addt->action = session("utilisateur")->idUser;
            $addt->save();
            Dossier::where('id', request("id"))->delete();
            flash("Suppression effectué avec succès."); return Back();
        }
    }

    public function getmdos(Request $request)
    {
        if (!in_array("update_vc", session("auto_action"))) {
            return view("vendor.error.649");
        }else{
            $info = DB::table("dossiers")->where('id', $request->id)->first();
            
            return view('viewadmindste.modifvcs', compact('info'));
        }
    }

    public function setmdos(Request $request)
    {
        if (!in_array("update_vc", session("auto_action"))) {
            return view("vendor.error.649");
        }else{
            $request->validate([
                    'prenom' => 'required|string', 
                    'nom' => 'required|string', 
                    'objet' => 'required|string', 
                    'montant' => 'required|integer', 
                    'datedebut' => 'required|date', 
                    'datefin' => 'required|date', 
                ]);

            Dossier::where('id', request('id'))->update(
                    [
                        'prenom' =>  htmlspecialchars(trim($request->prenom)),
                        'nom' =>  htmlspecialchars(trim($request->nom)),
                        'objet' => htmlspecialchars(trim($request->objet)),
                        'montant' => htmlspecialchars(trim($request->montant)),
                        'datedebut' => htmlspecialchars(trim($request->datedebut)),
                        'datefin' => htmlspecialchars(trim($request->datefin)),
                    ]);
            flash("Modification effectué avec succès. ")->success();
            TraceController::setTrace(
                "Vous avez modifié une donnée ".$request->libelle." .", session("utilisateur")->idUser);
            return redirect('/dashboard');
        }
    }

    /////////////////////////////// Fin dossiers /////////////////////////////////////////////

    /////////////////////////////// Rencontre ////////////////////////////////////////////////

    public function getrencontredos(Request $request)
    {
        if (!in_array("update_vc", session("auto_action"))) {
            return view("vendor.error.649");
        }else{
            $info = DB::table("dossiers")->where('id', $request->id)->first();

            $list = DB::table('rencontres')->where('dossier', $request->id)->paginate(50);
            
            return view('viewadmindste.rdv', compact('info', 'list'));
        }
    }

    public function setrencontredos(Request $request)
    {
        if(isset(Rencontre::where("id", $request->idrct)->first()->id)){
                Rencontre::where("id", $request->idrct)->update([
                    "nom" => $request->nom,
                    "prenom" => $request->prenom,
                    "date" => $request->daterdv,
                    "commentaire" => $request->commentaire,
                ]);

                return json_encode(["status"=> 0, "messages" => "Modification effectué avec succès "]);
            }else{
                if (isset(DB::table('rencontres')->where('date', $request->daterdv)->first()->id)) {
                    // Erreur 
                    flash("Une rencontre à cette date  été déjà exécuter ")->error();
                } else {
                     $request->validate([
                            'commentaire' => 'required|string', 
                            
                            'nom' => 'required|string',
                            'prenom' => 'required|string', 
                        ]);

                        $add = new Rencontre();
                        $add->dossier = $request->id;
                        $add->nom = $request->nom;
                        $add->prenom = $request->prenom;
                        $add->date = $request->daterdv;
                        $add->commentaire = $request->commentaire;
                        $add->save();

                        flash("Vous avez exécuter une rencontre. Enregistrement effectué avec succès.");
                        return Back();
                    
                }
                return Back();
            }
    }

    public function delrencontre(Request $request)
    {
        if (!in_array("delete_vc", session("auto_action"))) {
            return view("vendor.error.649");
        }else{
            $occurence = json_encode(Rencontre::where('id', request('id'))->first());
            $addt = new Trace();
            $addt->libelle = "Rencontre supprimé : ".$occurence;
            $addt->action = session("utilisateur")->idUser;
            $addt->save();
            Rencontre::where('id', request("id"))->delete();
            $info = "Suppression effectué avec succès.";
            return $info;
        }
    }

    /////////////////////////////// Fin rencontre /////////////////////////////////////////////

    /////////////////////////////// Trésorerie ///////////////////////////////////////////////

    public function gettresoreriedos(Request $request)
    {
        if (!in_array("update_vc", session("auto_action"))) {
            return view("vendor.error.649");
        }else{
            $info = DB::table("dossiers")->where('id', $request->id)->first();

            $list = DB::table('tresoreries')->where('dossier', $request->id)->paginate(50);
            
            return view('viewadmindste.tresorerie', compact('info', 'list'));
        }
    }

    public function settresoreriedos(Request $request)
    {
        
            $request->validate([
                    'lib' => 'required|string', 
                    'entre' => 'required|integer', 
                ]);

            $add = new Tresorerie();
            $add->dossier = $request->id;
            $add->libelle = $request->lib;
            $add->entre = $request->entre;
            $add->restant = $request->trestant;
            $add->date = date('d-m-Y');
            $add->save();

            // update montant payer in dossier
            Dossier::where('id', request('id'))->update(
                    [
                        'payer' => $request->payer + $request->entre,
                    ]);

            flash('Enregistrement effectué avec succès.');
        return Back();
    }

    public function deltresor(Request $request)
    {
        if (!in_array("delete_vc", session("auto_action"))) {
            return view("vendor.error.649");
        }else{
            $sole = Tresorerie::where('id', request('id'))->first();

            $payer = Dossier::where('id', $sole->dossier)->first()->payer;

            // update montant payer in dossier
            Dossier::where('id', $sole->dossier)->update(
                    [
                        'payer' => $payer - $sole->entre,
                    ]);

            $occurence = json_encode($sole);
            $addt = new Trace();
            $addt->libelle = "Tresorerie supprimé : ".$occurence;
            $addt->action = session("utilisateur")->idUser;
            $addt->save();
            Tresorerie::where('id', request("id"))->delete();
            $info = "Suppression effectué avec succès.";
            return $info;
        }
    }


    ////////////////////////////// Fin trésorerie ///////////////////////////////////////////


}
