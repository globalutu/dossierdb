@extends('templatedste._temp')
@section('css')

<!-- Bootstrap Select Css -->
<link href="cssdste/bootstrap-select/css/bootstrap-select.css" rel="stylesheet" />

@endsection
@section('content')

<div class="container-fluid">
	<div class="block-header">
		@include('flash-message')
		<h2>
		<a href="{{ route('dashboard') }}"> Tableau de bord </a> / Modification
			<small></small>
		</h2>
	</div>
	<div class="row clearfix">
		
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="card">
				<div class="header">
					<h2>
						Modification
					</h2>
				</div>
				<div class="body">
					<div class="row">
						
						<form style="padding : 20px" method="post" action="{{ route('SUVCS') }}" >
							<input type="hidden" name="_token" value="{{ csrf_token() }}" />
							<input type="hidden" name="id" value="{{ $info->id }}" />

							<div class="row clearfix">
                        <div class="col-md-6">
                                <label for="sousc">Souscripteur</label>
                                <div class="form-group">
                                <div class="form-line">
                                    <input type="text" id="sousc" name="sousc" value="{{ $info->souscripteur }}" class="form-control" placeholder="" required>
                                </div>
                                </div>
                        </div>

                        <div class="col-md-6">
                            <label for="pccom">Période couverte</label>
                           <div class="form-group">
                            <div class="form-line">
                                <input type="month" id="pccom" name="pccom" value="{{ $info->periode_couverte }}" class="form-control" required placeholder="">
                            </div>
                           </div>
                        </div>
                    </div>
                    <div class="row clearfix">
                        <div class="col-md-6">
                                <label for="dpcom">Date de préparation</label>
                                <div class="form-group">
                                <div class="form-line">
                                    <input type="date" id="dpcom" name="dpcom" value="{{ $info->per_preparation }}" class="form-control" required placeholder="">
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <label for="dscom">Date de signature</label>
                           <div class="form-group">
                            <div class="form-line">
                                <input type="date" id="dscom" name="dscom" value="{{ $info->datesignature }}" class="form-control" required placeholder="">
                            </div>
                           </div>
                        </div>
                    </div>
                    <div class="row clearfix">
                        <div class="col-md-6">
                                <label for="pvcs">Police</label>
                                <div class="form-group">
                                <div class="form-line">
                                    <input type="number" id="pvcs" name="pvcs" value="{{ $info->police }}" class="form-control" required placeholder="">
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <label for="prod">Produit</label>
                           <div class="form-group">
                            <div class="form-line">
                                <input type="text" id="prod" name="prod" value="{{ $info->produit }}" class="form-control" required placeholder="">
                            </div>
                           </div>
                        </div>
                    </div>
                    <div class="row clearfix">
                        <div class="col-md-6">
                                <label for="bascomm">Base commission</label>
                                <div class="form-group">
                                <div class="form-line">
                                    <input type="number" id="bascomm" value="{{ $info->base }}" name="bascomm"  required class="form-control" placeholder="">
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <label for="montcom">Montant commission</label>
                           <div class="form-group">
                            <div class="form-line">
                                <input type="number" id="montcom" value="{{ $info->montantcom }}" name="montcom" required class="form-control" placeholder="">
                            </div>
                           </div>
                        </div>
                    </div>
                    <div class="row clearfix">
                        <div class="col-md-12">
                                <label for="inter">Intermédiaire</label>
                                <div class="form-group">
                                <div class="form-line">
                                    <input type="text" id="inter" value="{{ $info->intermediaire }}" name="inter" required class="form-control" placeholder="">
                                </div>
                            </div>
                        </div>

                    </div>
                    		<div class="form-group" style="display: block;" >
								<div class="col-sm-12">
									<button type="submit" class="btn waves-effect" style="float:right; background-color: #795548; color: white; margin-top: 20px; margin-left: 15px; width: 25%;">Mettre à jour
									</button>
								</div>
							</div>
						</form>	
					</div>

				</div>
			</div>
		</div>
		
	</div>
</div>

@endsection

@section("js")
<script>
	$('#flash-overlay-modal').modal();
	$('div.alert').not('.alert-important').delay(6000).fadeOut(350);
</script>
@endsection