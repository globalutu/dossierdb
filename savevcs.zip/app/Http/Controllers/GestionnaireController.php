<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Providers\InterfaceServiceProvider;
use DB;
use App\Models\Trace;
use App\Models\Validcom as Com;

class GestionnaireController extends Controller
{
    //
    public function dash()
    {
        $list = DB::table('validcoms');
        
        if(request('rec') == 1){
            if(request('check') != "" && request('check') != null){
                $search = request('check');
                $list = $list->where('souscripteur', 'like', '%'.$search.'%')
                ->orwhere('periode_couverte', 'like', '%'.$search.'%')
                ->orwhere('intermediaire', 'like', '%'.$search.'%')
                ->orwhere('produit', 'like', '%'.$search.'%')
                ->orwhere('police', 'like', '%'.$search.'%')
                ->orwhere('datesignature', 'like', '%'.$search.'%')
                ->orwhere('per_preparation', 'like', '%'.$search.'%');
            }
        }
        $list = $list->orderby("id", "desc")->paginate(50);
        return view('viewadmindste.dash', compact("list"));
    }

    public function setvcs(Request $request){

    	if (isset(DB::table('validcoms')->where('intermediaire', $request->inter)->where('montantcom', $request->montcom)->where('produit', $request->prod)->where('periode_couverte', $request->pccom)->where('police', $request->pvcs)->first()->id)) {
    		// Erreur 
    		flash("Le souscripteur ".$request->sousc." sur la police ".$request->pvcs." a déjà obtenu une autorisation de payer pour la période du ".$request->pcco.". Merci de vérifier!")->error();
    	} else {
    		$request->validate([
                    'pccom' => 'required|string',
                    'sousc' => 'required|string', 
                    'dpcom' => 'required|date', 
                    'pvcs' => 'required|integer', 
                    'montcom' => 'required|integer', 
                    'prod' => 'required|string', 
                    'inter' => 'required|string', 
                    'bascomm' => 'required|integer', 
                    'dscom' => 'required|date', 
                ]);


    		$add = new Com();
	    	$add->souscripteur = $request->sousc;
	    	$add->periode_couverte = $request->pccom;
	    	$add->per_preparation = $request->dpcom;
	    	$add->police = $request->pvcs;
	    	$add->montantcom = $request->montcom;
	    	$add->produit = $request->prod;
	    	$add->intermediaire = $request->inter;
	    	$add->base = $request->bascomm;
	    	$add->datesignature = $request->dscom;
	    	$add->save();
	    	flash('Enregistrement effectué avec succès.');
    	}
    	return Back();

    }


    public function delvcs(Request $request)
    {
        if (!in_array("delete_vc", session("auto_action"))) {
            return view("vendor.error.649");
        }else{
            $occurence = json_encode(Com::where('id', request('id'))->first());
            $addt = new Trace();
            $addt->libelle = "VCS supprimé : ".$occurence;
            $addt->action = session("utilisateur")->idUser;
            $addt->save();
            Com::where('id', request("id"))->delete();
            flash("Suppression effectué avec succès."); return Back();
        }
    }

    public function getmvcs(Request $request)
    {
        if (!in_array("update_vc", session("auto_action"))) {
            return view("vendor.error.649");
        }else{
            $info = DB::table("validcoms")->where('id', $request->id)->first();
            
            return view('viewadmindste.modifvcs', compact('info'));
        }
    }

    public function setmvcs(Request $request)
    {
    	if (!in_array("update_vc", session("auto_action"))) {
            return view("vendor.error.649");
        }else{
            $request->validate([
                    'pccom' => 'required|string',
                    'sousc' => 'required|string', 
                    'dpcom' => 'required|date', 
                    'pvcs' => 'required|integer', 
                    'montcom' => 'required|integer', 
                    'prod' => 'required|string', 
                    'inter' => 'required|string', 
                    'bascomm' => 'required|integer', 
                    'dscom' => 'required|date', 
                ]);

            Com::where('id', request('id'))->update(
                    [
                        'souscripteur' =>  htmlspecialchars(trim($request->sousc)),
                        'periode_couverte' =>  htmlspecialchars(trim($request->pccom)),
                        'police' => htmlspecialchars(trim($request->pvcs)),
                        'montantcom' => htmlspecialchars(trim($request->montcom)),
                        'produit' => htmlspecialchars(trim($request->prod)),
                        'intermediaire' => htmlspecialchars(trim($request->inter)),
                        'base' => htmlspecialchars(trim($request->bascomm)),
                        'datesignature' => htmlspecialchars(trim($request->dscom)),
                        'per_preparation' => htmlspecialchars(trim($request->dpcom)),
                    ]);
            flash("Modification effectué avec succès. ")->success();
            TraceController::setTrace(
                "Vous avez modifié une donnée ".$request->libelle." .", session("utilisateur")->idUser);
            return redirect('/dashboard');
        }
    }
}
