<?php

use Illuminate\Support\Facades\Route;

Route::get('/cach',function () 
{
    Artisan::call('Config:cache');
});

Route::get('/', 'App\Http\Controllers\LoginController@login')->name('hoL');
Route::get('/connexion', 'App\Http\Controllers\LoginController@login')->name('login');
Route::post('/loginapi', 'App\Http\Controllers\LoginController@loginapi')->name('logapi');
Route::post('/connexion', 'App\Http\Controllers\LoginController@authenticate')->name('loginS');
Route::get('/mot-de-passe-oublié', 'App\Http\Controllers\LoginController@passmodif')->name('pass');

Route::fallback(function() {
   return view('vendor.error.404');
});
 
Route::group([
    'middleware' => 'App\Http\Middleware\Autorisation' 
 
], function(){
	
	Route::get('/deconnexion', 'App\Http\Controllers\LoginController@logout')->name('logout');
	

	//////////////////////////////////** VCS **/////////////////////////////////////////////////////////////////
	Route::post('/vcs', 'App\Http\Controllers\GestionnaireController@setvcs')->name('GMVCS');
	Route::post('/modifier-vcs', 'App\Http\Controllers\GestionnaireController@setmvcs')->name('SUVCS');
	Route::get('/modifier-vcs-{id}', 'App\Http\Controllers\GestionnaireController@getmvcs')->name('UVCS');
	Route::get('/supprimer-vcs-{id}', 'App\Http\Controllers\GestionnaireController@delvcs')->name('DVCS');
	
	///////////////////////////////////** Utilisateur **///////////////////////////////////////////////////////////

	Route::get('/dashboard', 'App\Http\Controllers\GestionnaireController@dash')->name('dashboard');
	Route::get('/utilisateur', 'App\Http\Controllers\UtilisateurController@getuser')->name('GU');
	Route::post('/utilisateur', 'App\Http\Controllers\UtilisateurController@adduser')->name('setuser');
	Route::get('/delete-utilisateur-{id}', 'App\Http\Controllers\UtilisateurController@deleteuser')->name('DU');
	Route::get('/reinitialiser-utilisateur-{id}', 'App\Http\Controllers\UtilisateurController@reinitialiseruser')->name('RU');
	Route::get('/desactivé-utilisateur-{id}', 'App\Http\Controllers\UtilisateurController@desactiveuser')->name('DSU');
	Route::get('/activé-utilisateur-{id}', 'App\Http\Controllers\UtilisateurController@activeuser')->name('ATU');
	Route::get('/modif-utilisateur-{id}', 'App\Http\Controllers\UtilisateurController@getmodifyuser')->name('MTU');
	Route::post('/modif-utilisateur', 'App\Http\Controllers\UtilisateurController@modifyuser')->name('MTUS');

	//////////////////////////////////** Rôle **/////////////////////////////////////////////////////////////////
	Route::get('/listroles', 'App\Http\Controllers\RoleController@listrole')->name('GR');
	Route::post('/roles', 'App\Http\Controllers\RoleController@addrole')->name('AR');
	Route::get('/modif-roles-{id}', 'App\Http\Controllers\RoleController@getmodifrole')->name('MTR');
	Route::get('/delete-roles-{id}', 'App\Http\Controllers\RoleController@deleterole')->name('DR');
	Route::get('/menu-roles-{id}', 'App\Http\Controllers\RoleController@getmenurole')->name('MRR');
	Route::post('/menu-roles', 'App\Http\Controllers\RoleController@setmenurole')->name('MenuAttr');
	Route::post('/modif-roles', 'App\Http\Controllers\RoleController@modifrole')->name('SRL');
 

	//////////////////////////////////** Menu **/////////////////////////////////////////////////////////////////
	Route::get('/listmenus', 'App\Http\Controllers\MenuController@getmenu')->name('GM');
	Route::post('/listmenus', 'App\Http\Controllers\MenuController@setmenu')->name('Menu_add');
	Route::get('/delete-menu-{id}', 'App\Http\Controllers\MenuController@delmenu')->name('DM');
	Route::get('/modif-menu-{id}', 'App\Http\Controllers\MenuController@getmodifmenu')->name('MTM');
	Route::post('/modif-menu', 'App\Http\Controllers\MenuController@setmodifmenu')->name('SML');
	Route::post('/action-menu', 'App\Http\Controllers\MenuController@setactionmenu')->name('Actionsave');
	Route::get('/action-menu-{id}', 'App\Http\Controllers\MenuController@getactionmenu')->name('ActionGet');

});